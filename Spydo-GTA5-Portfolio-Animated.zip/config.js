window.SPYDO_CONFIG = {
  brand: "!Spydo",
  logo: "assets/spydo-logo.png",
  siteTitle: "!Spydo",

  theme: {
    background: "#050505",
    panel: "#0b0b0b",
    white: "#f4f4f4",
    muted: "#929292",
    red: "#a90000",
    line: "#252525"
  },

  navigation: {
    work: { label: "Work", href: "#work" },
    system: { label: "System", href: "#system" },
    contact: { label: "Contact", href: "#contact" },
    cta: "Start a project ↗"
  },

  loader: {
    smallText: "INITIALIZING ASSET SYSTEM",
    duration: 1800
  },

  heroLogo: {
    right: "7%",
    top: "25%",
    width: "74%",
    moveX: "0px",
    moveY: "0px"
  },

  animations: {
    enabled: true,
    revealDistance: 35,
    revealDuration: 800,
    heroFloat: true,
    cursor: true,
    parallax: true,
    tiltCards: true,
    scanlines: true,
    glitch: true,
    glowPulse: true
  },

  hero: {
    eyebrow: "GTA V Asset Designer / 001",
    title: "!Spydo",
    outline: "WORKS",
    description: "CUSTOM GTA V CLOTHING AND DIGITAL ASSETS. AGGRESSIVE DIGITAL DESIGN WITH A DISTINCT IDENTITY.",
    primaryButton: "Explore work ↘",
    primaryHref: "#work",
    secondaryButton: "Contact ↗",
    secondaryHref: "#contact",
    scrollText: "SCROLL TO HUNT"
  },

  marquee: [
    "GTA V ASSETS",
    "VEHICLES",
    "3D MODELS",
    "!SPYDO",
    "FIVE M DEVELOPER"
  ],

  workSection: {
    kicker: "01 / SELECTED WORK",
    title: "THE DROP.",
    description: "Click any project to open its gallery.",
    viewButton: "VIEW ↗",
    categories: "auto"
  },

  systemSection: {
    kicker: "02 / DESIGN SYSTEM",
    quoteLine1: "BUILT TO LOOK",
    quoteAccent1: "FAST.",
    quoteLine2: "MADE TO HIT",
    quoteAccent2: "HARD.",
    principles: [
      { title: "01 / FORM", text: "Sharp silhouettes, hard geometry and visual weight." },
      { title: "02 / ENERGY", text: "Electric accents and controlled red highlights." },
      { title: "03 / MOTION", text: "Dynamic layouts with movement in every interaction." },
      { title: "04 / IDENTITY", text: "Every asset is designed to feel distinct inside the GTA V world." }
    ]
  },

  contact: {
    kicker: "03 / OPEN CHANNEL",
    titleLine1: "LET'S BUILD",
    titleLine2: "SOMETHING",
    titleAccent: "LOUD.",
    description: "Custom GTA V clothing and digital asset work.",
    email: "spydo.in@email.com",
    emailLabel: "Email !Spydo ↗",
    instagram: "https://instagram.com/@spydo.in",
    instagramLabel: "Instagram ↗",
    discord: "https://discord.gg/NtWUxJSRZ",
    discordLabel: "Discord ↗"
  },

  footer: {
    left: "© 2026 !SPYDO / ALL RIGHTS RESERVED",
    right: "!SPYDO // ONLINE"
  },

  projectPage: {
    backButton: "← All work",
    imageAltPrefix: "Project image"
  },

  projects: [
    {
      id: "work-01",
      name: "T-SHIRT / 01",
      category: "T-Shirts",
      type: "tee",
      short: "GTA V / CLOTHING",
      description: "Replace this with your T-shirt project description.",
      images: [
        "assets/works/work-01-01.svg",
        "assets/works/work-01-02.svg",
        "assets/works/work-01-03.svg"
      ]
    },
    {
      id: "work-02",
      name: "HOODIE / 02",
      category: "Hoodies",
      type: "hoodie",
      short: "GTA V / CLOTHING",
      description: "Replace this with your hoodie project description.",
      images: [
        "assets/works/work-02-01.svg",
        "assets/works/work-02-02.svg",
        "assets/works/work-02-03.svg"
      ]
    },
    {
      id: "work-03",
      name: "JACKET / 03",
      category: "Jackets",
      type: "jacket",
      short: "GTA V / CLOTHING",
      description: "Replace this with your jacket project description.",
      images: [
        "assets/works/work-03-01.svg",
        "assets/works/work-03-02.svg",
        "assets/works/work-03-03.svg"
      ]
    },
    {
      id: "work-04",
      name: "LIVERY / 04",
      category: "Liveries",
      type: "livery",
      short: "GTA V / VEHICLE",
      description: "Replace this with your livery project description.",
      images: [
        "assets/works/work-04-01.svg",
        "assets/works/work-04-02.svg",
        "assets/works/work-04-03.svg"
      ]
    },
    {
      id: "work-05",
      name: "T-SHIRT / 05",
      category: "T-Shirts",
      type: "tee",
      short: "GTA V / CLOTHING",
      description: "Replace this with your fifth project description.",
      images: [
        "assets/works/work-05-01.svg",
        "assets/works/work-05-02.svg",
        "assets/works/work-05-03.svg"
      ]
    }
  ]
};
