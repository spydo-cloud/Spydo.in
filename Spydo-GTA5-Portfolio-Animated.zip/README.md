# !Spydo — GTA V Portfolio

Single-index GitHub Pages portfolio with an aggressive Electric Cat identity.

## Files
- `index.html` — the entire site and all styling/scripts
- `config.js` — edit your content, colors, hero logo position, animation settings, links and projects
- `assets/spydo-logo.png` — your !Spydo logo
- `assets/works/` — project gallery images
- `.nojekyll` — GitHub Pages compatibility

## Edit the cat position
In `config.js`:
```js
heroLogo: {
  right: "7%",
  top: "25%",
  width: "74%",
  moveX: "0px",
  moveY: "0px"
}
```

## Animation controls
```js
animations: {
  enabled: true,
  revealDistance: 35,
  revealDuration: 800,
  heroFloat: true,
  cursor: true,
  parallax: true,
  tiltCards: true,
  scanlines: true,
  glitch: true,
  glowPulse: true
}
```

## Add a project
Add another object to `projects` and put three images in `assets/works/`.

## GitHub Pages
Upload the contents of this folder to the repository root. Enable Pages from the `main` branch and root folder.
